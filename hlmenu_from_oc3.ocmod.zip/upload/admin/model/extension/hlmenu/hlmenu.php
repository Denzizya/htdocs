<?php

class ModelExtensionHlmenuHlmenu extends Model
{
    public function install() {
        $this->db->query("
            CREATE TABLE  `" . DB_PREFIX . "hello` (
            `id` INT NOT NULL AUTO_INCREMENT ,
            `time` INT NOT NULL , PRIMARY KEY (`id`))
            ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "hello`");
	}

    public function hlList ()
    {
        $query = $this->db->query("SELECT * FROM ".DB_PREFIX."hello");
        $result = "";
        foreach($query->rows as $row)
        {
            $time_table = date("d-m-Y  H:i:s", $row["time"]);
            $result .= "<tr><td>" . $row["id"] . "</td><td>" . $time_table . "</td></tr>";
        }
        return $result;
    }
}