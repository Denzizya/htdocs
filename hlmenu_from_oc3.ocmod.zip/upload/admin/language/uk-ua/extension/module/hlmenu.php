<?php

// Heading
$_['heading_title']     = 'Hello';

// Column
$_['column_name']       = 'ID';
$_['column_action']     = 'Дата';

// Text
$_['text_list']         = 'Лог відображення "Hello, OpenCart!"';
$_['text_enabled']      = 'Увімкнений';
$_['text_disabled']     = 'Вимкнений';

// Entry
$_['entry_name']        = 'Модуль Hello!';
$_['entry_title']       = 'Заголовок';
$_['entry_status']      = 'Статус';
