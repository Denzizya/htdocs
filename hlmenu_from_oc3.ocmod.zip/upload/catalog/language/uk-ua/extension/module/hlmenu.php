<?php
// Entry
$_['entry_name']        = 'Модуль Hello!';