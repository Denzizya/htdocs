<?php
class ModelExtensionHlmenuHlmenu extends Model
{
    public function toDB ()
    {
        $this->db->query("INSERT INTO `".DB_PREFIX."hello` (`id`, `time`) VALUES (NULL, '".time()."')");
    }
}