<?php

class ControllerExtensionModuleHlmenu extends Controller
{
	public function index()
    {
        if (!$this->customer->isLogged()){return false;}

        $this->load->language('extension/module/hlmenu');
		$data['module_hlmenu_title'] = html_entity_decode($this->config->get('module_hlmenu_title'), ENT_QUOTES, 'UTF-8');
		return $this->load->view('extension/module/hlmenu', $data);
    }

    public function send_db ()
    {
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($this->request->post['time']))
        {
            $this->load->model('extension/hlmenu/hlmenu');
            $this->model_extension_hlmenu_hlmenu->toDB();
		}
	}

}